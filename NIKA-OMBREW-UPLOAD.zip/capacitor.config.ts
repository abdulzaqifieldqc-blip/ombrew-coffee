import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.nikaombrew.coffee',
  appName: 'NIKA x OMBrew Coffee',
  webDir: 'www',
  bundledWebRuntime: false
};
export default config;
