NIKA x OMBrew Coffee - GitHub APK build

Upload the CONTENTS of this folder to the root of the GitHub repository.
Do not rename www/index.html.
The product images are already embedded inside index.html, so the large duplicate assets folder is intentionally omitted.
