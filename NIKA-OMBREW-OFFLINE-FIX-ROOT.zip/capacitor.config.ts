import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.nikaombrew.coffee',
  appName: 'NIKA × OMBrew Coffee',
  webDir: 'www',
  bundledWebRuntime: false
};
export default config;
