import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nikaombrew.coffee',
  appName: 'NIKA × OMBrew Coffee',
  webDir: 'www'
};

export default config;
