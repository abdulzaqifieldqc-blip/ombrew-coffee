NIKA × OMBrew Coffee

Offline Android app source.
Master HTML filename: www/index.html
Local menu/order data is stored on-device.
